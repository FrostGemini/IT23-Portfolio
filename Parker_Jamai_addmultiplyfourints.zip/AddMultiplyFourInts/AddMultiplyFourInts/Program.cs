﻿using System;

namespace AddMultiplyFourInts
{
    class Program
    {
        static void Main(string[] args)
        {
            // Initialize four integer variables
            int num1 = 13;
            int num2 = 55;
            int num3 = 123;
            int num4 = 325;

            // Calculate the sum and product
            int sum = num1 + num2 + num3 + num4;
            int product = num1 * num2 * num3 * num4;

            // Output the results to match the required sample
            Console.WriteLine("Jamai's Copy");
            Console.WriteLine($"The sum of {num1}, {num2}, {num3}, and {num4} = {sum}");
            Console.WriteLine($"The product of {num1}, {num2}, {num3}, and {num4} = {product}");

            // Keep console open and match final line
            Console.Write("Press any key to continue . . . ");
            Console.ReadKey();
        }
    }
}