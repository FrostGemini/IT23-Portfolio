﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DebugFixMethods
{
    class Program
    {
        static void Main(string[] args)
        {
            (new Program()).run();
        }


        void run()
        {

            //Added to match the required output format
            Console.WriteLine("Teacher's Copy");

            int choice = 0;

            WritePrompt();
            choice = ReadChoice();
            WriteChoice(choice);

            //Added to pause the console window
            Console.Write("Press any key to continue . . . ");
            Console.ReadKey();

        }

        //Error fix: Capitalized the 'P' in WritePrompt to match the method name
        void WritePrompt()
        {
            Console.WriteLine("Please select a course for which you want to register by typing the number inside []");
            Console.WriteLine("[1]IT 145\n[2]IT 200\n[3]IT 201\n[4]IT 270\n[5]IT 315\n[6]IT 328\n[7]IT 330");
            Console.Write("Enter your choice : ");
        }

        int ReadChoice()
        {
            string s = "";
            s = Console.ReadLine();
            //ERROR fix: Parsed string 's' to integer to match int return type
            return int.Parse(s);
        }

        //Error fix: Added the missing 'int' data type
        void WriteChoice(int choice)
        {
            //Error fix: Changed 'Choice' to 'choice' to match the parameter name
            Console.WriteLine("Your choice is {0}", choice);
        }
    }
}