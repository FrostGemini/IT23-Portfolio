﻿using System;

namespace CreateClassesObjs
{
    public class Course
    {
        // Private string field to hold the name of the course
        private string name;

        // Method to set the name field to a given string value
        public void setName(string courseName)
        {
            this.name = courseName;
        }

        // Method to retrieve the name field
        public string getName()
        {
            return this.name;
        }

        // Overridden ToString() method to return the name field for WPF display
        public override string ToString()
        {
            return this.name;
        }
    }
}